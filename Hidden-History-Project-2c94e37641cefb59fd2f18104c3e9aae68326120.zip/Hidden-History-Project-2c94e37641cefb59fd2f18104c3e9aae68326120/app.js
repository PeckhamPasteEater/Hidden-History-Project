const VISITED_KEY = "hidden-history-visited";

function getVisited() {
  return JSON.parse(localStorage.getItem(VISITED_KEY)) || {};
}

function saveVisited(data) {
  localStorage.setItem(VISITED_KEY, JSON.stringify(data));
}

let notified = new Set();

const defaultIcon = L.icon({
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41]
});

const visitedIcon = L.icon({
  iconUrl: "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-green.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41]
});

let notificationsEnabled = false;

/* ---------- MAP SETUP ---------- */
const map = L.map("map");

const tileLayer = L.tileLayer(
  "https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png",
  {
    maxZoom: 19,
    attribution: "© OpenStreetMap © CARTO"
  }
).addTo(map);

/* ---------- MARKERS ---------- */
const markers = {};
const bounds = [];

locations.forEach(loc => {
  if (typeof loc.lat !== "number" || typeof loc.lng !== "number") return;

  const visited = getVisited()[loc.id];

  const marker = L.marker(
    [loc.lat, loc.lng],
    { icon: visited ? visitedIcon : defaultIcon }
  ).addTo(map);

  marker.bindTooltip(loc.title, {
    permanent: true,
    direction: "bottom",
    offset: [0, 10],
    className: "pin-label"
  });

  marker.on("click", () => openInfo(loc));

  markers[loc.id] = marker;
  bounds.push([loc.lat, loc.lng]);
});

/* Zoom map to show all pins */
if (bounds.length > 0) {
  map.fitBounds(bounds, { padding: [40, 40] });
} else {
  map.setView([51.505, -0.09], 13);
}

/* ---------- INFO PANEL ---------- */
function openInfo(loc) {
  document.getElementById("info-title").textContent = loc.title;
  document.getElementById("info-description").textContent = loc.description;
  document.getElementById("info-image").src = loc.image || "";
  document.getElementById("info-panel").classList.remove("hidden");
}

function closeInfo() {
  document.getElementById("info-panel").classList.add("hidden");
}

/* ---------- SEARCH ---------- */
document.getElementById("search").addEventListener("input", e => {
  const q = e.target.value.toLowerCase();

  locations.forEach(loc => {
    const marker = markers[loc.id];
    if (!marker) return;

    if (loc.title.toLowerCase().includes(q)) {
      marker.addTo(map);
    } else {
      map.removeLayer(marker);
    }
  });
});

/* ---------- NOTIFICATIONS ---------- */
async function notify(loc) {
  if (!notificationsEnabled) return;
  if (Notification.permission !== "granted") return;
  if (notified.has(loc.id)) return;

  notified.add(loc.id);

  const reg = await navigator.serviceWorker.ready;

  reg.showNotification("Hidden History Nearby", {
    body: loc.title,
    data: loc.id
  });
}

/* ---------- LOCATION TRACKING ---------- */
let userMarker;

if ("geolocation" in navigator) {
  navigator.geolocation.watchPosition(
    pos => {
      const user = [pos.coords.latitude, pos.coords.longitude];

      if (!userMarker) {
        userMarker = L.circleMarker(user, {
          radius: 6,
          color: "#007aff",
          fillColor: "#007aff",
          fillOpacity: 1
        }).addTo(map);
      } else {
        userMarker.setLatLng(user);
      }

      locations.forEach(loc => {
        const dist = map.distance(user, [loc.lat, loc.lng]);
        if (dist < 50) {
          notify(loc);
          markVisited(loc);
        }
      });
    },
    err => console.error("Geolocation error", err),
    { enableHighAccuracy: true, maximumAge: 10000, timeout: 10000 }
  );
}

/* ---------- SERVICE WORKER ---------- */
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("./service-worker.js");
}

/* ---------- AUTO OPEN FROM NOTIFICATION / HASH ---------- */
let pendingHashId = null;

// Capture hash as early as possible
if (window.location.hash) {
  pendingHashId = window.location.hash.substring(1);
}

// Function to open a location by ID (handles iOS map quirks)
function openLocationById(id) {
  if (!id) return;
  const loc = locations.find(l => l.id === id);
  if (!loc) return;

  // Wait for Leaflet map to fully initialize
  setTimeout(() => {
    map.invalidateSize(true); // critical on iOS
    map.setView([loc.lat, loc.lng], 17, { animate: true });
    openInfo(loc);
  }, 300);

  pendingHashId = null;
  history.replaceState(null, "", window.location.pathname);
}

// Run on all relevant events
window.addEventListener("load", () => openLocationById(pendingHashId));
window.addEventListener("pageshow", () => openLocationById(pendingHashId));
window.addEventListener("hashchange", () => {
  pendingHashId = window.location.hash.substring(1);
  openLocationById(pendingHashId);
});

/* ---------- START APP BUTTON ---------- */
window.addEventListener("DOMContentLoaded", () => {
  const startBtn = document.getElementById("start-app");
  if (!startBtn) return;

  startBtn.addEventListener("click", async () => {
    if ("Notification" in window) {
      const permission = await Notification.requestPermission();
      if (permission === "granted") notificationsEnabled = true;
    }

    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(() => {}, () => {});
    }

    document.getElementById("splash").style.display = "none";
  });
});

/* ---------- VISITED ---------- */
function markVisited(loc) {
  const visited = getVisited();
  if (visited[loc.id]) return;

  visited[loc.id] = new Date().toISOString();
  saveVisited(visited);

  const marker = markers[loc.id];
  if (marker) marker.setIcon(visitedIcon);
}

function openVisited() {
  const list = document.getElementById("visited-list");
  list.innerHTML = "";
  const visited = getVisited();
  const entries = Object.entries(visited)
    .sort((a, b) => new Date(b[1]) - new Date(a[1]));

  if (entries.length === 0) list.innerHTML = "<li>No places visited yet.</li>";

  entries.forEach(([id, dateString]) => {
    const loc = locations.find(l => l.id === id);
    if (!loc) return;

    const li = document.createElement("li");
    const date = new Date(dateString);
    const formatted = date.toLocaleDateString(undefined, {
      year: "numeric", month: "short", day: "numeric"
    });

    li.innerHTML = `<strong>${loc.title}</strong><br><small>Visited ${formatted}</small>`;
    li.onclick = () => {
      map.setView([loc.lat, loc.lng], 17);
      openInfo(loc);
      closeVisited();
    };

    list.appendChild(li);
  });

  document.getElementById("visited-panel").classList.remove("hidden");
  document.body.style.overflow = "hidden";
}

function closeVisited() {
  document.getElementById("visited-panel").classList.add("hidden");
  document.body.style.overflow = "";
}


const visitedPanel = document.getElementById("visited-panel");
const openVisitedBtn = document.getElementById("open-visited");

openVisitedBtn.addEventListener("click", () => {
  visitedPanel.classList.remove("hidden");
});


window.addEventListener("DOMContentLoaded", () => {
  const visitedBtn = document.getElementById("open-visited");
  if (!visitedBtn) return;
  visitedBtn.addEventListener("click", openVisited);
});
